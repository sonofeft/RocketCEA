

Authors
=======

Thank you for supporting RocketCEA.

Development Lead
----------------

* `Charlie Taylor <https://github.com/sonofeft>`_

Patches and Ideas
-----------------

 *Your Name Here*

Initial Project Layout
----------------------

RocketCEA Framework was Created by: `PyHatch <http://pyhatch.readthedocs.org/en/latest/>`_ 

(PyHatch Initializes Files And Directory Structures For New Python Projects.)

See PyHatch Docs at: `<http://pyhatch.readthedocs.org/en/latest/>`_
